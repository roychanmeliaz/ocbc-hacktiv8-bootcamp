INSERT INTO db_bank.dbo.tb_offices (city,phone,addressLine1,addressLine2,state,country,postalCode,territory) VALUES
	 (N'Jakarta Pusat',N'021021',N'jl. satrio',N'-',N'DKI Jakarta',N'Indonesia',N'73635',N'-'),
	 (N'Jakarta Selatan',N'021666',N'jl. jalan',N'-',N'DKI Jakarta',N'Indonesia',N'36254',N'-'),
	 (N'Jakarta Utara',N'021333',N'jl. baru',N'-',N'DKI Jakarta',N'Indonesia',N'84635',N'-'),
	 (N'Jakarta Timur',N'021222',N'jl. lama',N'-',N'DKI Jakarta',N'Indonesia',N'38274',N'-'),
	 (N'Jakarta Barat',N'021111',N'jl. sini',N'-',N'DKI Jakarta',N'Indonesia',N'37294',N'-');