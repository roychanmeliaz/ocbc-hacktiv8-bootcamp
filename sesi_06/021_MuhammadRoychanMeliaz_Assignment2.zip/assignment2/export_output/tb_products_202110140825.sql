INSERT INTO db_bank.dbo.tb_products (productName,productLine,productScale,productVendor,productDescription,quantityInStock,buyPrice,MSRP) VALUES
	 (N'Huawei Band 6',0,N'5',N'Huawei',N'Smart band',200,650000,N'500000'),
	 (N'Seagate HDD 1 TB',0,N'7',N'Seagate',N'External Hard Disk',300,1100000,N'1000000'),
	 (N'Hada Labo Face Wash',1,N'6',N'Hada Labo',N'Face Wash',4000,35000,N'35000'),
	 (N'Susu Bendera Frision Flag',2,N'5',N'Frision Flag',N'Susu kental manis',1300,25000,N'23000'),
	 (N'Susu Dancow',2,N'10',N'Nestle',N'Susu',500,52000,N'50000');