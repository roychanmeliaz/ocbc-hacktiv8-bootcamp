INSERT INTO db_bank.dbo.tb_productlines (textDescription,htmlDescription,[image]) VALUES
	 (N'Electronics',N'electronics.html',N'electronics.jpg'),
	 (N'Cosmetics',N'cosmetics.html',N'cosmetics.jpg'),
	 (N'Milk',N'milk.html',N'milk.jpg'),
	 (N'Games',N'games.html',N'games.jpg'),
	 (N'Clothing',N'clothing.html',N'clothing.jpg');