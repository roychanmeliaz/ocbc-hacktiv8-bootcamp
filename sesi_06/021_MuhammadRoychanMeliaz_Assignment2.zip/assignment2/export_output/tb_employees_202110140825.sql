INSERT INTO db_bank.dbo.tb_employees (lastName,firstName,extension,email,officeCode,reportsTo,jobTitle) VALUES
	 (N'angelina',N'nia',N'-',N'nia@mail.com',0,0,N'Head Of Everything'),
	 (N'elva',N'grace',N'-',N'grace@mail.com',1,0,N'Head Of Office'),
	 (N'risa',N'tanisha',N'-',N'tanisha@mail.com',1,1,N'Office boy'),
	 (N'liudvya',N'may',N'-',N'may@mail.com',2,1,N'counter'),
	 (N'hanum',N'nadila',N'-',N'nad@mail.com',2,1,N'office staff');