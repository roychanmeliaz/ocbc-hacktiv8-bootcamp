INSERT INTO db_bank.dbo.tb_customers (customerName,contactLastName,contactFirstName,phone,addressLine1,addressLine2,city,state,postalCode,country,salesRepEmployeeNumber,creditLimit) VALUES
	 (N'Roy',N'Meliaz',N'Roychan',N'082391906848',N'jl. muka kuning no 8',N'jl. keputih no3',N'Batam',N'Kepulauan Riau',N'29438',N'Indonesia',1,20000000),
	 (N'Fadhil',N'Ihsan',N'Fadhil',N'08123456789',N'jl. ali haji no 21',N'-',N'Semarang',N'Jawa Tengah',N'11223',N'Indonesia',1,15000000),
	 (N'Dzaky',N'Mulyanto',N'Dzaky',N'08080808088',N'jl. keputih no 3',N'jl. kasuari no 22',N'Surabaya',N'Jawa Timur',N'60111',N'Indonesia',2,30000000),
	 (N'Fuad',N'Zakiy',N'Fuad',N'082659377594',N'jl. rajawali no 19',N'-',N'Bandung',N'Jawa Barat',N'74937',N'Indonesia',2,40000000),
	 (N'Faisal',N'Rizal',N'Faisal',N'0834775t2333',N'jl. mulyosari no 1',N'jl. keputih no 11',N'Surabaya',N'Jawa Timur',N'60111',N'Indonesia',3,30000000);