INSERT INTO db_bank.dbo.tb_orderdetails (productCode,quantityOrdered,priceEach,orderLineNumber) VALUES
	 (0,1,650000,0),
	 (1,2,1100000,1),
	 (2,1,35000,2),
	 (3,3,25000,3),
	 (4,1,52000,4);