using TodoApp.Configuration;

namespace TodoApp.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}