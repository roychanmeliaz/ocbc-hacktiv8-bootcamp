using Payment.Configuration;
using PaymentJWT.Configuration;

namespace Payment.Models.DTOs.Responses 
{
    public class RegistrationResponse : AuthResult
    {

    }
}