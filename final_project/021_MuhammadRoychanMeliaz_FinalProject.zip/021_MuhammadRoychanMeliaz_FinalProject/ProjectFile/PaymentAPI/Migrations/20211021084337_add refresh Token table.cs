﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace apiPayment.Migrations
{
    public partial class addrefreshTokentable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
